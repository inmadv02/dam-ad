package com.salesianostriana.dam;

import com.salesianostriana.dam.model.Producto;
import com.salesianostriana.dam.repos.ProductoRepositorio;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.persistence.EntityManager;
import java.util.List;

import static org.junit.Assert.assertEquals;


@ExtendWith(SpringExtension.class)
@DataJpaTest
public class ProductoRepositoryTest {

    @Autowired
    ApplicationContext context;

    @Autowired
    private EntityManager entityManager;

    @Autowired
    private ProductoRepositorio repositorio;

    @Test
    void testFindAll_success(){

        Producto p1 = Producto
                        .builder()
                        .nombre("Pan")
                        .build();

        Producto p2 = Producto
                .builder()
                .nombre("Manzana").build();


        entityManager.persist(p1);
        entityManager.persist(p2);

        List<Producto> lista = repositorio.findAll();

        assertEquals(2, lista.size());
    }

    @Test
    void test2(){

        List<Producto> result = repositorio.findByNombreContainsIgnoreCase("pan");

        assertEquals(1, result.size());
    }
}
