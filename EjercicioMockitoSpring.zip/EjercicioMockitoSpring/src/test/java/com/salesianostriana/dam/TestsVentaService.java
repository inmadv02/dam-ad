package com.salesianostriana.dam;

import com.salesianostriana.dam.model.Cliente;
import com.salesianostriana.dam.model.LineaDeVenta;
import com.salesianostriana.dam.model.Producto;
import com.salesianostriana.dam.model.Venta;
import com.salesianostriana.dam.repos.ProductoRepositorio;
import com.salesianostriana.dam.repos.VentaRepositorio;
import com.salesianostriana.dam.service.VentaServicio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;

@ExtendWith(SpringExtension.class)
public class TestsVentaService {

    @MockBean
    VentaRepositorio ventaRepositorio;

    @MockBean
    ProductoRepositorio productoRepositorio;


    VentaServicio ventaServicio;


    @BeforeEach
    public void setUp(){
        ventaServicio = new VentaServicio(productoRepositorio, ventaRepositorio);
    }

    @Test
    public void createsNewVenta(){

        Cliente cliente = new Cliente("12345678H", "Pedro");
        Producto producto = Producto.builder()
                .id(4L)
                .codigoProducto("123")
                .nombre("Leche Semidesnatada")
                .precio(1)
                .build();

        Map<Long, Integer> carrito = Map.of(4L, 2);



        Venta v = new Venta();
        v.setId(2L);
        v.setCliente(cliente);
        v.setLineasDeVenta(List.of(new LineaDeVenta(producto,2, producto.getPrecio())));

        lenient().when(productoRepositorio.findById(any(Long.class))).thenReturn(Optional.of(producto));

        lenient().when(ventaRepositorio.save(any(Venta.class))).thenReturn(v);

        Venta result = ventaServicio.nuevaVenta(carrito, cliente);

        assertEquals(1, result.getLineasDeVenta().size());


    }

    @Test
    void productExists(){
        Optional<Producto> producto = productoRepositorio.findById(1L);

        assertThat(producto.isPresent());

    }

    @Test
    public void ventaExists(){

        Optional<Venta> v = ventaRepositorio.findById(2L);

        assertThat(v.isPresent());
    }


    @Test
    void deletedProduct(){

        Cliente cliente = new Cliente("12345678H", "Pedro");
        Producto producto = Producto.builder()
                .id(4L)
                .codigoProducto("123")
                .nombre("Leche Semidesnatada")
                .precio(1)
                .build();

        Map<Long, Integer> carrito = Map.of(4L, 2);

        lenient().when(productoRepositorio.findById(4L)).thenReturn(Optional.ofNullable(producto));

        LineaDeVenta lineaDeVenta = new LineaDeVenta(producto, 2, 1);

        Venta v = new Venta();
        v.setId(2L);
        v.setCliente(cliente);
        v.setLineasDeVenta(List.of(lineaDeVenta));

        lenient().when(ventaRepositorio.save(v)).thenReturn(v);

        ventaServicio.nuevaVenta(carrito, cliente);

        assertEquals(v, ventaServicio.removeLineaVenta(v.getId(), lineaDeVenta.getId()));

    }


}
