package com.salesianostriana.dam.EjercicioClase_InmaculadaDominguezVargas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioClaseInmaculadaDominguezVargasApplicationTests {

	@Test
	void contextLoads() {
	}

}
