package com.salesianostriana.dam.E06_InmaculadaDominguezVargas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class E06InmaculadaDominguezVargasApplicationTests {

	@Test
	void contextLoads() {
	}

}
