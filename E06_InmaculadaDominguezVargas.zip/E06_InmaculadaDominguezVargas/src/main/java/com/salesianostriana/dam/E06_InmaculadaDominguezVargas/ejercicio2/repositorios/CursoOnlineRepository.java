package com.salesianostriana.dam.E06_InmaculadaDominguezVargas.ejercicio2.repositorios;

import com.salesianostriana.dam.E06_InmaculadaDominguezVargas.ejercicio2.model.CursoOnline;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CursoOnlineRepository extends JpaRepository<CursoOnline, Long> {
}
