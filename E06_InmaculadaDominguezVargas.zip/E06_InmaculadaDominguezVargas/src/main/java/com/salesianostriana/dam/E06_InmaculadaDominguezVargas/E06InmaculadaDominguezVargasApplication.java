package com.salesianostriana.dam.E06_InmaculadaDominguezVargas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class E06InmaculadaDominguezVargasApplication {

	public static void main(String[] args) {
		SpringApplication.run(E06InmaculadaDominguezVargasApplication.class, args);
	}

}
